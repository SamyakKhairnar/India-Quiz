var readlineSync = require('readline-sync');
const chalk = require('chalk');

console.log(chalk.green.bgMagenta.bold('Welcom to My India Quiz'));

var score = 0;

console.log(chalk.blueBright.bold('\n1] Who Was First PM Of India ?'));
  quesOne = ['Indira Gandhi', 'Narendra Modi', 'Jawaharlal Nehru', 'Rajiv Gandhi'],
  index = readlineSync.keyInSelect(quesOne, 'Enter Option');
  if(index == 2){
  console.log(chalk.red.bold('Correct !'));
  score++;
  }else{
    console.log("Wrong ! Correct Answer was "+ chalk.red.bold(quesOne[2]));
  }

console.log(chalk.blueBright.bold('\n2] What is the capital city of India ?'));
  quesTwo = ['New Delhi', 'Mumbai', 'Kolkata', 'Chennai'],
  index = readlineSync.keyInSelect(quesTwo, 'Enter Option');
  if(index == 0){
  console.log(chalk.red.bold('Correct !'));
  score++;
  }else{
    console.log("Wrong ! Correct Answer was "+ chalk.red.bold(quesTwo[0]));
  }

console.log(chalk.blueBright.bold('\n3] Which is the national sport of India ?'));
  quesThree = ['Cricket', 'Hockey', 'Kabaddi', 'Football'],
  index = readlineSync.keyInSelect(quesThree, 'Enter Option');
  if(index == 1){
  console.log(chalk.red.bold('Correct !'));
  score++;
  }else{
    console.log("Wrong ! Correct Answer was "+ chalk.red.bold(quesThree[1]));
  }

 console.log(chalk.blueBright.bold('\n4] Who is the chief architect of the Indian Constitution ?'));
  quesFour = ['Abul Kalam Azad', 'Jawaharlal Nehru', 'Sardar Vallabhbhai Patel', 'Dr.Bhimrao Ambedkar'],
  index = readlineSync.keyInSelect(quesFour, 'Enter Option');
  if(index == 3){
  console.log(chalk.red.bold('Correct !'));
  score++;
  }else{
    console.log("Wrong ! Correct Answer was "+ chalk.red.bold(quesFour[3]));
  } 

 console.log(chalk.blueBright.bold('\n5] Who founded the Indian National Army ?'));
  quesFive = ['Subhas Chandra Bose', 'Mohan Singh', 'Chandra Shekhar Azad', 'Bhagat Singh'],
  index = readlineSync.keyInSelect(quesFive, 'Enter Option');
  if(index == 1){
  console.log(chalk.red.bold('Correct !'));
  score++;
  }else{
    console.log("Wrong ! Correct Answer was "+ chalk.red.bold(quesFive[1]));
  }  

  if (score > 3){
    console.log("\nHurray ! You Did Fabulous.\nYour Score is : " + chalk.red.bold(score));
  }else{
    console.log("\nYou Might Need to Learn More About India.\nYour Score is : " + chalk.red.bold(score));
  }